# Downloads

Please see [Releases History](https://github.com/ververica/flink-cdc-connectors/releases)
